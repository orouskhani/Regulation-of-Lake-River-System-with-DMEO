package edu.sharif.ce.nipl.dmoo.business;

import java.util.Random;

import org.uma.jmetal.util.front.Front;
import org.uma.jmetal.util.front.imp.ArrayFront;
import org.uma.jmetal.util.point.impl.ArrayPoint;

import edu.sharif.ce.nipl.dmoo.CSO;
import edu.sharif.ce.nipl.dmoo.entity.Cat;


public class Benchmark {

	private int nVar;
	private double minVar;
	private double maxVar;
	private double nt;
	private double towet;
	private int nVar1;
	private double minVar1;
	private int nVar2;
	private double maxVar1;
	private double minVar2;
	private double maxVar2;
	private int func;
	private static int r;
	private static boolean flag;

	double[] xkGoal; 

	private Random rnd;

	private static final double step = 0.01;

	public Benchmark(int nVar1 , int nVar2 , double minVar1 , double maxVar1 , double minVar2 , double maxVar2 , int func , int towet , int nt) {
		super();

		this.nVar = nVar1 + nVar2;
		this.nVar1 = nVar1;
		this.nVar2 = nVar2;

		this.minVar1 = minVar1;
		this.maxVar1 = maxVar1;

		this.minVar2 = minVar2;
		this.maxVar2 = maxVar2;

		this.func = func;

		rnd = new Random();

		r = -1;
		flag = false;

		xkGoal = new double[]{2.1493,2.2575,2.8407,2.2543,2.8143,2.2435,2.9293,2.35,2.1966,2.2511,2.616,2.4733,2.3517,2.8308,2.5853,2.5497,2.9172,2.2858,2.7572,2.7537,2.3804,2.5678,2.0759,2.054};

		this.towet = towet;
		this.nt = nt;
	}

	public double area(double level){
		return level * 12 + 200;
	}

	public double evaluate(Cat cat, int relatedFunction , int iter){
		if(func == CSO.LAKERIVER){
			return lakeRiver(cat, relatedFunction, iter);
		}
		else
			return 0;

	}


	//FDA1
	public double lakeRiver(Cat cat, int relatedFunction , int iter){
		double cG = 10;
		double cI = 100;
		double c1 = 100;
		double c2 = 0.00001;
		double deltaQMax = 300;
		double lk = 2.1;
		double uk = 2.9;
		double[] position = cat.getPosition();

		double[] xbar = new double[xkGoal.length];
		xbar[0] = 3;
		for(int i = 1 ; i < xkGoal.length ; i++){
			double deltaq = position[i] - position[i + 24];
			xbar[i] = xbar[i-1] + deltaq / area(xbar[i-1]);
		}

		double result = 0;
		if(relatedFunction == 0){	
			double[] x = new double [xkGoal.length];
			x[0] = 2.5;
			for(int i = 1 ; i < xkGoal.length ; i++){
				double deltaq = position[i] - position[i + 24];
				double deltaX = deltaq / area((x[i-1] + xbar[i]) / 2);
				x[i] = x[i-1] + deltaX;
			}

			double gk = 0;
			for(int i = 0 ; i < xkGoal.length ; i++)
				gk += Math.pow(xkGoal[i] - x[i], 2);

			double[] p = new double[x.length];
			for(int i = 0 ; i < p.length ; i++){
				double deltaq = position[i] - position[i + 24];
				if(deltaq > deltaQMax){
					p[i] = c1 * (Math.pow(Math.abs(deltaq) - deltaQMax, 2)) + c2 * (Math.pow(deltaq, 2));
				}
				else{
					p[i] = c2 * (Math.pow(deltaq, 2));
				}
			}

			double sigmaP = 0;
			for(int i = 0 ; i < p.length ; i++){
				sigmaP += p[i];
			}
			result = cG * gk + sigmaP;  
		}
		else if (relatedFunction == 1){

			double[] x = new double [xkGoal.length];
			x[0] = 2.5;
			for(int i = 1 ; i < xkGoal.length ; i++){
				double deltaq = position[i] - position[i + 24];
				double deltaX = deltaq / area((x[i-1] + xbar[i]) / 2);
				x[i] = x[i-1] + deltaX;
			}

			double[] Ik = new double[x.length];
			for(int i = 0 ; i < Ik.length ; i++){
				if(x[i] < lk){
					Ik[i] = Math.pow(lk - x[i], 2); 
				}
				else if(x[i] > uk){
					Ik[i] = Math.pow(uk - x[i], 2); 
				}
				else
					Ik[i] = 0;
			}

			double sigmaI = 0;
			for(int i = 0 ; i < Ik.length ; i++){
				sigmaI += Ik[i];
			}

			double[] p = new double[x.length];
			for(int i = 0 ; i < p.length ; i++){
				double deltaq = position[i] - position[i + 24];
				if(deltaq > deltaQMax){
					p[i] = c1 * (Math.pow(Math.abs(deltaq) - deltaQMax, 2)) + c2 * (Math.pow(deltaq, 2));
				}
				else{
					p[i] = c2 * (Math.pow(deltaq, 2));
				}
			}

			double sigmaP = 0;
			for(int i = 0 ; i < p.length ; i++){
				sigmaP += p[i];
			}

			result = cI * sigmaI + sigmaP;

		}
		return result;
	}

	public Front generatePFTrueForCONTELEVER(){
		Front PFTrue = new ArrayFront(100 , 2);

		double i = 0;
		int index = 0;
		while(i <= 1){
			double x = i;
			double y = 1 - Math.sqrt(i);
			PFTrue.setPoint(index, new ArrayPoint(new double[]{x,y}));
			index++;
			i += step;
		}
		return PFTrue;
	}

	public double[] getX(Cat cat){
		double[] position = cat.getPosition();

		double[] xbar = new double[xkGoal.length];
		xbar[0] = 3;
		for(int i = 1 ; i < xkGoal.length ; i++){
			double deltaq = position[i] - position[i + 24];
			xbar[i] = xbar[i-1] + deltaq / area(xbar[i-1]);
		}

		double[] x = new double [xkGoal.length];
		x[0] = 2.5;
		for(int i = 1 ; i < xkGoal.length ; i++){
			double deltaq = position[i] - position[i + 24];
			double deltaX = deltaq / area((x[i-1] + xbar[i]) / 2);
			x[i] = x[i-1] + deltaX;
		}
		
		return x;

	}

}
